CSI477-2019-01 - Proposta de Trabalho Final

Grupo: David Fune Fabiio Duarte
Resumo
O objetivo deste documento é apresentar uma proposta para o trabalho a ser desenvolvido na disciplina CSI477 -- Sistemas WEB I. É uma breve descrição sobre o tema que será abordado, bem como o escopo, as restrições e demais questões pertinentes ao contexto, de um sistema web para compra de pacote de turismos via web site.


1. Tema
O trabalho final tem como tema o desenvolvimento um web site onde se possa realizar as compras de pacote de turismo e visualir detalhes sobre eles.

2. Escopo
Este projeto terá as seguintes funcionalidades, um moderador para alimentar um sistema com uma tela inicial,uma tela para visualizar os pacotes de viagens já existentes que leva a uma tela com possibilidade de editar e e deletar um pacote de viagem.
Também contará com as telas de login de um usuário, cadastro e uma tela de início para visualizar os pacotes em uma tela com detalhes dos pacotes com a opção comprar.

3. Restrições
As restrições até o momento são que o trabalho realiza apenas as interações de telas e ainda não envia informações para um banco, também exist

4. Protótipo
Cliente Web:
	cadastrasUsuario.html
	detalhePacote.html
	login.html
	principal.htm

moderador
	form.html
	index.html
	table.html

5. Referências
https://getbootstrap.com/docs/4.0/getting-started/introduction/
